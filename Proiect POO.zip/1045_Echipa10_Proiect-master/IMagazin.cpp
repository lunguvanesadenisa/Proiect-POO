#include "IMagazin.h"
